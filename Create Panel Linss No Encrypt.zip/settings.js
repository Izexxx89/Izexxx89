const fs = require('fs')
const chalk = require('chalk')

global.owner = ['6285624509791'] 
global.bugrup = ['6285624509791'] 
global.packname = 'RilzMods' //nama lu
global.author = 'RilzStore ✓' //nama lu
global.domain = "https://xenzsenpai.sanzz-hosting.my.id/server/ff80da65/files/edit#/config.js" // domain lu (pakai https)
global.apikey = 'ptla_Y0B5WJtWs9QI7tvxFkLRBU1MP9wkSbSh8RXlrWSim88' //apikey ptla lu
global.capikey = 'ptlc_JFoI6PMShg1yuELYNx6tYjN1yVjnyz7vkI8kl5CXjQX' // apikey ptlc lu

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})

// SILAHKAN SETTING SESUAI PERINTAH //